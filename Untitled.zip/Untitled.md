```python
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
import plotly.express as px
from wordcloud import WordCloud, STOPWORDS, ImageColorGenerator
from sklearn.model_selection import train_test_split
from sklearn.linear_model import PassiveAggressiveRegressor
%matplotlib inline
from selenium import webdriver
from selenium.webdriver.common.by import By
from pprint import pprint

```


```python
import json
df=pd.read_json("dataset_instagram-api-scraper_2023-05-29_11-54-31-918.json")
df.head(6)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>hashtags</th>
      <th>likesCount</th>
      <th>commentsCount</th>
      <th>highlightReelCount</th>
      <th>igtvVideoCount</th>
      <th>caption</th>
      <th>type</th>
      <th>postsCount</th>
      <th>timestamp</th>
      <th>followsCount</th>
      <th>followersCount</th>
      <th>videoViewCount</th>
      <th>productType</th>
      <th>videoPlayCount</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>[]</td>
      <td>507</td>
      <td>16</td>
      <td>14</td>
      <td>6686</td>
      <td>اللجنة الوطنية للانتخابات تنشر قوائم الهيئات ا...</td>
      <td>Image</td>
      <td>103372</td>
      <td>2015-07-05 15:32:34+00:00</td>
      <td>15</td>
      <td>2566997</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>1</th>
      <td>[]</td>
      <td>658</td>
      <td>13</td>
      <td>14</td>
      <td>6686</td>
      <td>.\nكل أسبوع خلال أيام عروض الشارقة للتسوق نك...</td>
      <td>Video</td>
      <td>103372</td>
      <td>2020-08-08 11:30:01+00:00</td>
      <td>15</td>
      <td>2566997</td>
      <td>11053.0</td>
      <td>feed</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>2</th>
      <td>[Repost, الإمارات]</td>
      <td>493</td>
      <td>9</td>
      <td>14</td>
      <td>6686</td>
      <td>#Repost @uae_barq with @repostapp. ・・・ 👆👆موقع ...</td>
      <td>Image</td>
      <td>103372</td>
      <td>2014-12-18 11:31:17+00:00</td>
      <td>15</td>
      <td>2566997</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>3</th>
      <td>[]</td>
      <td>413</td>
      <td>1</td>
      <td>14</td>
      <td>6686</td>
      <td>تحتفل الإمارات ب «يوم المرأة» بدورته الأولى في...</td>
      <td>Image</td>
      <td>103372</td>
      <td>2015-08-28 09:16:29+00:00</td>
      <td>15</td>
      <td>2566997</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>4</th>
      <td>[]</td>
      <td>438</td>
      <td>25</td>
      <td>14</td>
      <td>6686</td>
      <td>‏لا اله إلا الله وحده لا شريك له . له الحمد ول...</td>
      <td>Image</td>
      <td>103372</td>
      <td>2014-08-07 21:51:40+00:00</td>
      <td>15</td>
      <td>2566997</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>5</th>
      <td>[أحب_محمد_بن_زايد, تويتر, الآن, من, أبناء, الو...</td>
      <td>628</td>
      <td>8</td>
      <td>14</td>
      <td>6686</td>
      <td>#أحب_محمد_بن_زايد \nوسم فعال في #تويتر ❤️\n#ال...</td>
      <td>Image</td>
      <td>103372</td>
      <td>2015-08-25 16:03:59+00:00</td>
      <td>15</td>
      <td>2566997</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
  </tbody>
</table>
</div>




```python
df.describe()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>likesCount</th>
      <th>commentsCount</th>
      <th>highlightReelCount</th>
      <th>igtvVideoCount</th>
      <th>postsCount</th>
      <th>followsCount</th>
      <th>followersCount</th>
      <th>videoViewCount</th>
      <th>videoPlayCount</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>count</th>
      <td>191.000000</td>
      <td>191.000000</td>
      <td>191.0</td>
      <td>191.0</td>
      <td>191.0</td>
      <td>191.0</td>
      <td>191.0</td>
      <td>2.000000</td>
      <td>0.0</td>
    </tr>
    <tr>
      <th>mean</th>
      <td>206.157068</td>
      <td>10.052356</td>
      <td>14.0</td>
      <td>6686.0</td>
      <td>103372.0</td>
      <td>15.0</td>
      <td>2566997.0</td>
      <td>9102.500000</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>std</th>
      <td>230.399462</td>
      <td>27.675134</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>2758.423553</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>min</th>
      <td>4.000000</td>
      <td>0.000000</td>
      <td>14.0</td>
      <td>6686.0</td>
      <td>103372.0</td>
      <td>15.0</td>
      <td>2566997.0</td>
      <td>7152.000000</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>25%</th>
      <td>38.000000</td>
      <td>1.000000</td>
      <td>14.0</td>
      <td>6686.0</td>
      <td>103372.0</td>
      <td>15.0</td>
      <td>2566997.0</td>
      <td>8127.250000</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>50%</th>
      <td>112.000000</td>
      <td>3.000000</td>
      <td>14.0</td>
      <td>6686.0</td>
      <td>103372.0</td>
      <td>15.0</td>
      <td>2566997.0</td>
      <td>9102.500000</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>75%</th>
      <td>330.500000</td>
      <td>7.000000</td>
      <td>14.0</td>
      <td>6686.0</td>
      <td>103372.0</td>
      <td>15.0</td>
      <td>2566997.0</td>
      <td>10077.750000</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>max</th>
      <td>1044.000000</td>
      <td>206.000000</td>
      <td>14.0</td>
      <td>6686.0</td>
      <td>103372.0</td>
      <td>15.0</td>
      <td>2566997.0</td>
      <td>11053.000000</td>
      <td>NaN</td>
    </tr>
  </tbody>
</table>
</div>




```python
df.info()
```

    <class 'pandas.core.frame.DataFrame'>
    RangeIndex: 191 entries, 0 to 190
    Data columns (total 14 columns):
     #   Column              Non-Null Count  Dtype              
    ---  ------              --------------  -----              
     0   hashtags            191 non-null    object             
     1   likesCount          191 non-null    int64              
     2   commentsCount       191 non-null    int64              
     3   highlightReelCount  191 non-null    int64              
     4   igtvVideoCount      191 non-null    int64              
     5   caption             191 non-null    object             
     6   type                191 non-null    object             
     7   postsCount          191 non-null    int64              
     8   timestamp           191 non-null    datetime64[ns, UTC]
     9   followsCount        191 non-null    int64              
     10  followersCount      191 non-null    int64              
     11  videoViewCount      2 non-null      float64            
     12  productType         2 non-null      object             
     13  videoPlayCount      0 non-null      float64            
    dtypes: datetime64[ns, UTC](1), float64(2), int64(7), object(4)
    memory usage: 21.0+ KB
    


```python
df.isnull().sum()
```




    hashtags                0
    likesCount              0
    commentsCount           0
    highlightReelCount      0
    igtvVideoCount          0
    caption                 0
    type                    0
    postsCount              0
    timestamp               0
    followsCount            0
    followersCount          0
    videoViewCount        189
    productType           189
    videoPlayCount        191
    dtype: int64




```python
data = df.dropna()
```


```python
data.info()
```

    <class 'pandas.core.frame.DataFrame'>
    Int64Index: 0 entries
    Data columns (total 14 columns):
     #   Column              Non-Null Count  Dtype              
    ---  ------              --------------  -----              
     0   hashtags            0 non-null      object             
     1   likesCount          0 non-null      int64              
     2   commentsCount       0 non-null      int64              
     3   highlightReelCount  0 non-null      int64              
     4   igtvVideoCount      0 non-null      int64              
     5   caption             0 non-null      object             
     6   type                0 non-null      object             
     7   postsCount          0 non-null      int64              
     8   timestamp           0 non-null      datetime64[ns, UTC]
     9   followsCount        0 non-null      int64              
     10  followersCount      0 non-null      int64              
     11  videoViewCount      0 non-null      float64            
     12  productType         0 non-null      object             
     13  videoPlayCount      0 non-null      float64            
    dtypes: datetime64[ns, UTC](1), float64(2), int64(7), object(4)
    memory usage: 0.0+ bytes
    

# Distribution of videoViewCount


```python
plt.figure(figsize=(10, 8))
plt.style.use('fivethirtyeight')
plt.title("Distribution of Impressions From videoViewCount")
sns.distplot(df['videoViewCount'])
plt.show()
```

    C:\Users\Figo\AppData\Local\Temp\ipykernel_9052\228143262.py:4: UserWarning:
    
    
    
    `distplot` is a deprecated function and will be removed in seaborn v0.14.0.
    
    Please adapt your code to use either `displot` (a figure-level function with
    similar flexibility) or `histplot` (an axes-level function for histograms).
    
    For a guide to updating your code to use the new functions, please see
    https://gist.github.com/mwaskom/de44147ed2974457ad6372750bbe5751
    
    
    


    
![png](output_8_1.png)
    


# Distribution of likesCount


```python
plt.figure(figsize=(10, 8))
plt.style.use('fivethirtyeight')
plt.title("Distribution of Impressions From likesCount")
sns.distplot(df['likesCount'])
plt.show()
```

    C:\Users\Figo\AppData\Local\Temp\ipykernel_9052\185601827.py:4: UserWarning:
    
    
    
    `distplot` is a deprecated function and will be removed in seaborn v0.14.0.
    
    Please adapt your code to use either `displot` (a figure-level function with
    similar flexibility) or `histplot` (an axes-level function for histograms).
    
    For a guide to updating your code to use the new functions, please see
    https://gist.github.com/mwaskom/de44147ed2974457ad6372750bbe5751
    
    
    


    
![png](output_10_1.png)
    


# Distribution of commentsCount


```python
plt.figure(figsize=(10, 8))
plt.style.use('fivethirtyeight')
plt.title("Distribution of Impressions From commentsCount")
sns.distplot(df['commentsCount'])
plt.show()
```

    C:\Users\Figo\AppData\Local\Temp\ipykernel_9052\1886878830.py:4: UserWarning:
    
    
    
    `distplot` is a deprecated function and will be removed in seaborn v0.14.0.
    
    Please adapt your code to use either `displot` (a figure-level function with
    similar flexibility) or `histplot` (an axes-level function for histograms).
    
    For a guide to updating your code to use the new functions, please see
    https://gist.github.com/mwaskom/de44147ed2974457ad6372750bbe5751
    
    
    


    
![png](output_12_1.png)
    



```python
like = df["likesCount"].sum()
comments = df["commentsCount"].sum()
Videos = df['videoViewCount'].sum()

labels = ['likesCount','commentsCount','videoViewCount']
values = [like, comments,Videos]


fig = px.pie(data, values=values, names=labels, 
             title='Impressions on Instagram Posts From Various Sources', hole=0.5)
fig.show()
```


<div>                            <div id="6392b0f3-558c-49b8-a3f9-c16f3710e2a4" class="plotly-graph-div" style="height:525px; width:100%;"></div>            <script type="text/javascript">                require(["plotly"], function(Plotly) {                    window.PLOTLYENV=window.PLOTLYENV || {};                                    if (document.getElementById("6392b0f3-558c-49b8-a3f9-c16f3710e2a4")) {                    Plotly.newPlot(                        "6392b0f3-558c-49b8-a3f9-c16f3710e2a4",                        [{"domain":{"x":[0.0,1.0],"y":[0.0,1.0]},"hole":0.5,"hovertemplate":"label=%{label}<br>value=%{value}<extra></extra>","labels":["likesCount","commentsCount","videoViewCount"],"legendgroup":"","name":"","showlegend":true,"values":[39376.0,1920.0,18205.0],"type":"pie"}],                        {"template":{"data":{"histogram2dcontour":[{"type":"histogram2dcontour","colorbar":{"outlinewidth":0,"ticks":""},"colorscale":[[0.0,"#0d0887"],[0.1111111111111111,"#46039f"],[0.2222222222222222,"#7201a8"],[0.3333333333333333,"#9c179e"],[0.4444444444444444,"#bd3786"],[0.5555555555555556,"#d8576b"],[0.6666666666666666,"#ed7953"],[0.7777777777777778,"#fb9f3a"],[0.8888888888888888,"#fdca26"],[1.0,"#f0f921"]]}],"choropleth":[{"type":"choropleth","colorbar":{"outlinewidth":0,"ticks":""}}],"histogram2d":[{"type":"histogram2d","colorbar":{"outlinewidth":0,"ticks":""},"colorscale":[[0.0,"#0d0887"],[0.1111111111111111,"#46039f"],[0.2222222222222222,"#7201a8"],[0.3333333333333333,"#9c179e"],[0.4444444444444444,"#bd3786"],[0.5555555555555556,"#d8576b"],[0.6666666666666666,"#ed7953"],[0.7777777777777778,"#fb9f3a"],[0.8888888888888888,"#fdca26"],[1.0,"#f0f921"]]}],"heatmap":[{"type":"heatmap","colorbar":{"outlinewidth":0,"ticks":""},"colorscale":[[0.0,"#0d0887"],[0.1111111111111111,"#46039f"],[0.2222222222222222,"#7201a8"],[0.3333333333333333,"#9c179e"],[0.4444444444444444,"#bd3786"],[0.5555555555555556,"#d8576b"],[0.6666666666666666,"#ed7953"],[0.7777777777777778,"#fb9f3a"],[0.8888888888888888,"#fdca26"],[1.0,"#f0f921"]]}],"heatmapgl":[{"type":"heatmapgl","colorbar":{"outlinewidth":0,"ticks":""},"colorscale":[[0.0,"#0d0887"],[0.1111111111111111,"#46039f"],[0.2222222222222222,"#7201a8"],[0.3333333333333333,"#9c179e"],[0.4444444444444444,"#bd3786"],[0.5555555555555556,"#d8576b"],[0.6666666666666666,"#ed7953"],[0.7777777777777778,"#fb9f3a"],[0.8888888888888888,"#fdca26"],[1.0,"#f0f921"]]}],"contourcarpet":[{"type":"contourcarpet","colorbar":{"outlinewidth":0,"ticks":""}}],"contour":[{"type":"contour","colorbar":{"outlinewidth":0,"ticks":""},"colorscale":[[0.0,"#0d0887"],[0.1111111111111111,"#46039f"],[0.2222222222222222,"#7201a8"],[0.3333333333333333,"#9c179e"],[0.4444444444444444,"#bd3786"],[0.5555555555555556,"#d8576b"],[0.6666666666666666,"#ed7953"],[0.7777777777777778,"#fb9f3a"],[0.8888888888888888,"#fdca26"],[1.0,"#f0f921"]]}],"surface":[{"type":"surface","colorbar":{"outlinewidth":0,"ticks":""},"colorscale":[[0.0,"#0d0887"],[0.1111111111111111,"#46039f"],[0.2222222222222222,"#7201a8"],[0.3333333333333333,"#9c179e"],[0.4444444444444444,"#bd3786"],[0.5555555555555556,"#d8576b"],[0.6666666666666666,"#ed7953"],[0.7777777777777778,"#fb9f3a"],[0.8888888888888888,"#fdca26"],[1.0,"#f0f921"]]}],"mesh3d":[{"type":"mesh3d","colorbar":{"outlinewidth":0,"ticks":""}}],"scatter":[{"fillpattern":{"fillmode":"overlay","size":10,"solidity":0.2},"type":"scatter"}],"parcoords":[{"type":"parcoords","line":{"colorbar":{"outlinewidth":0,"ticks":""}}}],"scatterpolargl":[{"type":"scatterpolargl","marker":{"colorbar":{"outlinewidth":0,"ticks":""}}}],"bar":[{"error_x":{"color":"#2a3f5f"},"error_y":{"color":"#2a3f5f"},"marker":{"line":{"color":"#E5ECF6","width":0.5},"pattern":{"fillmode":"overlay","size":10,"solidity":0.2}},"type":"bar"}],"scattergeo":[{"type":"scattergeo","marker":{"colorbar":{"outlinewidth":0,"ticks":""}}}],"scatterpolar":[{"type":"scatterpolar","marker":{"colorbar":{"outlinewidth":0,"ticks":""}}}],"histogram":[{"marker":{"pattern":{"fillmode":"overlay","size":10,"solidity":0.2}},"type":"histogram"}],"scattergl":[{"type":"scattergl","marker":{"colorbar":{"outlinewidth":0,"ticks":""}}}],"scatter3d":[{"type":"scatter3d","line":{"colorbar":{"outlinewidth":0,"ticks":""}},"marker":{"colorbar":{"outlinewidth":0,"ticks":""}}}],"scattermapbox":[{"type":"scattermapbox","marker":{"colorbar":{"outlinewidth":0,"ticks":""}}}],"scatterternary":[{"type":"scatterternary","marker":{"colorbar":{"outlinewidth":0,"ticks":""}}}],"scattercarpet":[{"type":"scattercarpet","marker":{"colorbar":{"outlinewidth":0,"ticks":""}}}],"carpet":[{"aaxis":{"endlinecolor":"#2a3f5f","gridcolor":"white","linecolor":"white","minorgridcolor":"white","startlinecolor":"#2a3f5f"},"baxis":{"endlinecolor":"#2a3f5f","gridcolor":"white","linecolor":"white","minorgridcolor":"white","startlinecolor":"#2a3f5f"},"type":"carpet"}],"table":[{"cells":{"fill":{"color":"#EBF0F8"},"line":{"color":"white"}},"header":{"fill":{"color":"#C8D4E3"},"line":{"color":"white"}},"type":"table"}],"barpolar":[{"marker":{"line":{"color":"#E5ECF6","width":0.5},"pattern":{"fillmode":"overlay","size":10,"solidity":0.2}},"type":"barpolar"}],"pie":[{"automargin":true,"type":"pie"}]},"layout":{"autotypenumbers":"strict","colorway":["#636efa","#EF553B","#00cc96","#ab63fa","#FFA15A","#19d3f3","#FF6692","#B6E880","#FF97FF","#FECB52"],"font":{"color":"#2a3f5f"},"hovermode":"closest","hoverlabel":{"align":"left"},"paper_bgcolor":"white","plot_bgcolor":"#E5ECF6","polar":{"bgcolor":"#E5ECF6","angularaxis":{"gridcolor":"white","linecolor":"white","ticks":""},"radialaxis":{"gridcolor":"white","linecolor":"white","ticks":""}},"ternary":{"bgcolor":"#E5ECF6","aaxis":{"gridcolor":"white","linecolor":"white","ticks":""},"baxis":{"gridcolor":"white","linecolor":"white","ticks":""},"caxis":{"gridcolor":"white","linecolor":"white","ticks":""}},"coloraxis":{"colorbar":{"outlinewidth":0,"ticks":""}},"colorscale":{"sequential":[[0.0,"#0d0887"],[0.1111111111111111,"#46039f"],[0.2222222222222222,"#7201a8"],[0.3333333333333333,"#9c179e"],[0.4444444444444444,"#bd3786"],[0.5555555555555556,"#d8576b"],[0.6666666666666666,"#ed7953"],[0.7777777777777778,"#fb9f3a"],[0.8888888888888888,"#fdca26"],[1.0,"#f0f921"]],"sequentialminus":[[0.0,"#0d0887"],[0.1111111111111111,"#46039f"],[0.2222222222222222,"#7201a8"],[0.3333333333333333,"#9c179e"],[0.4444444444444444,"#bd3786"],[0.5555555555555556,"#d8576b"],[0.6666666666666666,"#ed7953"],[0.7777777777777778,"#fb9f3a"],[0.8888888888888888,"#fdca26"],[1.0,"#f0f921"]],"diverging":[[0,"#8e0152"],[0.1,"#c51b7d"],[0.2,"#de77ae"],[0.3,"#f1b6da"],[0.4,"#fde0ef"],[0.5,"#f7f7f7"],[0.6,"#e6f5d0"],[0.7,"#b8e186"],[0.8,"#7fbc41"],[0.9,"#4d9221"],[1,"#276419"]]},"xaxis":{"gridcolor":"white","linecolor":"white","ticks":"","title":{"standoff":15},"zerolinecolor":"white","automargin":true,"zerolinewidth":2},"yaxis":{"gridcolor":"white","linecolor":"white","ticks":"","title":{"standoff":15},"zerolinecolor":"white","automargin":true,"zerolinewidth":2},"scene":{"xaxis":{"backgroundcolor":"#E5ECF6","gridcolor":"white","linecolor":"white","showbackground":true,"ticks":"","zerolinecolor":"white","gridwidth":2},"yaxis":{"backgroundcolor":"#E5ECF6","gridcolor":"white","linecolor":"white","showbackground":true,"ticks":"","zerolinecolor":"white","gridwidth":2},"zaxis":{"backgroundcolor":"#E5ECF6","gridcolor":"white","linecolor":"white","showbackground":true,"ticks":"","zerolinecolor":"white","gridwidth":2}},"shapedefaults":{"line":{"color":"#2a3f5f"}},"annotationdefaults":{"arrowcolor":"#2a3f5f","arrowhead":0,"arrowwidth":1},"geo":{"bgcolor":"white","landcolor":"#E5ECF6","subunitcolor":"white","showland":true,"showlakes":true,"lakecolor":"white"},"title":{"x":0.05},"mapbox":{"style":"light"}}},"legend":{"tracegroupgap":0},"title":{"text":"Impressions on Instagram Posts From Various Sources"}},                        {"responsive": true}                    ).then(function(){

var gd = document.getElementById('6392b0f3-558c-49b8-a3f9-c16f3710e2a4');
var x = new MutationObserver(function (mutations, observer) {{
        var display = window.getComputedStyle(gd).display;
        if (!display || display === 'none') {{
            console.log([gd, 'removed!']);
            Plotly.purge(gd);
            observer.disconnect();
        }}
}});

// Listen for the removal of the full notebook cells
var notebookContainer = gd.closest('#notebook-container');
if (notebookContainer) {{
    x.observe(notebookContainer, {childList: true});
}}

// Listen for the clearing of the current output cell
var outputEl = gd.closest('.output');
if (outputEl) {{
    x.observe(outputEl, {childList: true});
}}

                        })                };                });            </script>        </div>



```python
text = " ".join(i for i in df.caption)
stopwords = set(STOPWORDS)
wordcloud = WordCloud(stopwords=stopwords, background_color="white").generate(text)
plt.style.use('classic')
plt.figure( figsize=(12,10))
plt.imshow(wordcloud, interpolation='bilinear')
plt.axis("off")
plt.show()
```


    
![png](output_14_0.png)
    



```python
figure = px.scatter(data_frame = df, x="commentsCount",
                    y="likesCount", size="likesCount", trendline="ols", 
                    title = "Relationship Between Likes and Comments")
figure.show()
```


<div>                            <div id="67ce5b25-cc51-4143-b2ba-3a932df39ed8" class="plotly-graph-div" style="height:525px; width:100%;"></div>            <script type="text/javascript">                require(["plotly"], function(Plotly) {                    window.PLOTLYENV=window.PLOTLYENV || {};                                    if (document.getElementById("67ce5b25-cc51-4143-b2ba-3a932df39ed8")) {                    Plotly.newPlot(                        "67ce5b25-cc51-4143-b2ba-3a932df39ed8",                        [{"hovertemplate":"commentsCount=%{x}<br>likesCount=%{marker.size}<extra></extra>","legendgroup":"","marker":{"color":"#636efa","size":[507,658,493,413,438,628,547,543,655,381,468,456,218,428,443,440,483,163,312,336,431,341,378,192,128,199,413,657,19,46,60,41,29,33,15,78,350,39,162,68,29,83,22,50,484,22,165,80,152,113,1044,350,22,28,184,24,100,18,19,23,73,24,21,229,122,47,139,36,26,512,36,86,899,207,23,148,44,53,17,325,54,37,134,52,116,45,50,552,399,372,31,312,814,34,318,46,450,42,63,23,37,146,957,650,50,470,67,112,551,147,94,11,236,38,33,34,28,174,133,206,21,28,347,63,21,240,48,425,50,274,38,64,45,26,535,72,233,484,83,205,15,1034,38,316,32,171,93,82,139,108,37,56,930,39,967,249,160,63,4,152,93,23,503,48,14,147,80,10,440,53,55,164,485,28,16,221,714,152,33,147,114,52,149,42,10,96,172,134,281,21,6],"sizemode":"area","sizeref":2.61,"symbol":"circle"},"mode":"markers","name":"","orientation":"v","showlegend":false,"x":[16,13,9,1,25,8,3,6,24,0,1,7,2,14,4,5,2,0,1,1,5,7,6,2,0,6,1,6,0,5,1,13,1,3,0,4,8,0,0,3,1,4,1,5,7,2,2,10,1,2,112,6,2,0,2,0,3,0,2,2,0,0,1,3,0,2,1,0,6,11,5,2,180,30,3,11,1,3,0,21,0,6,1,4,8,1,1,17,3,2,4,1,10,0,11,2,2,3,9,0,0,4,134,95,3,20,6,7,22,9,1,0,8,0,2,1,2,4,14,2,0,0,14,2,0,4,0,3,3,10,0,0,7,0,29,0,16,24,9,21,0,206,1,15,1,22,3,1,3,0,2,2,137,2,17,2,5,1,0,5,1,1,13,4,1,11,2,0,16,2,1,12,3,1,0,3,142,10,7,5,2,4,7,5,0,1,11,7,5,0,0],"xaxis":"x","y":[507,658,493,413,438,628,547,543,655,381,468,456,218,428,443,440,483,163,312,336,431,341,378,192,128,199,413,657,19,46,60,41,29,33,15,78,350,39,162,68,29,83,22,50,484,22,165,80,152,113,1044,350,22,28,184,24,100,18,19,23,73,24,21,229,122,47,139,36,26,512,36,86,899,207,23,148,44,53,17,325,54,37,134,52,116,45,50,552,399,372,31,312,814,34,318,46,450,42,63,23,37,146,957,650,50,470,67,112,551,147,94,11,236,38,33,34,28,174,133,206,21,28,347,63,21,240,48,425,50,274,38,64,45,26,535,72,233,484,83,205,15,1034,38,316,32,171,93,82,139,108,37,56,930,39,967,249,160,63,4,152,93,23,503,48,14,147,80,10,440,53,55,164,485,28,16,221,714,152,33,147,114,52,149,42,10,96,172,134,281,21,6],"yaxis":"y","type":"scatter"},{"hovertemplate":"<b>OLS trendline</b><br>likesCount = 5.46652 * commentsCount + 151.206<br>R<sup>2</sup>=0.431159<br><br>commentsCount=%{x}<br>likesCount=%{y} <b>(trend)</b><extra></extra>","legendgroup":"","marker":{"color":"#636efa","symbol":"circle"},"mode":"lines","name":"","showlegend":false,"x":[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,4,4,4,4,4,4,4,4,4,4,5,5,5,5,5,5,5,5,5,5,6,6,6,6,6,6,6,6,7,7,7,7,7,7,7,7,8,8,8,8,9,9,9,9,10,10,10,10,11,11,11,11,11,12,13,13,13,14,14,14,15,16,16,16,17,17,20,21,21,22,22,24,24,25,29,30,95,112,134,137,142,180,206],"xaxis":"x","y":[151.20570186332898,151.20570186332898,151.20570186332898,151.20570186332898,151.20570186332898,151.20570186332898,151.20570186332898,151.20570186332898,151.20570186332898,151.20570186332898,151.20570186332898,151.20570186332898,151.20570186332898,151.20570186332898,151.20570186332898,151.20570186332898,151.20570186332898,151.20570186332898,151.20570186332898,151.20570186332898,151.20570186332898,151.20570186332898,151.20570186332898,151.20570186332898,151.20570186332898,151.20570186332898,151.20570186332898,151.20570186332898,151.20570186332898,151.20570186332898,151.20570186332898,151.20570186332898,151.20570186332898,151.20570186332898,151.20570186332898,151.20570186332898,151.20570186332898,156.6722179800499,156.6722179800499,156.6722179800499,156.6722179800499,156.6722179800499,156.6722179800499,156.6722179800499,156.6722179800499,156.6722179800499,156.6722179800499,156.6722179800499,156.6722179800499,156.6722179800499,156.6722179800499,156.6722179800499,156.6722179800499,156.6722179800499,156.6722179800499,156.6722179800499,156.6722179800499,156.6722179800499,156.6722179800499,156.6722179800499,156.6722179800499,156.6722179800499,156.6722179800499,156.6722179800499,156.6722179800499,156.6722179800499,162.1387340967708,162.1387340967708,162.1387340967708,162.1387340967708,162.1387340967708,162.1387340967708,162.1387340967708,162.1387340967708,162.1387340967708,162.1387340967708,162.1387340967708,162.1387340967708,162.1387340967708,162.1387340967708,162.1387340967708,162.1387340967708,162.1387340967708,162.1387340967708,162.1387340967708,162.1387340967708,162.1387340967708,162.1387340967708,162.1387340967708,162.1387340967708,162.1387340967708,162.1387340967708,167.60525021349173,167.60525021349173,167.60525021349173,167.60525021349173,167.60525021349173,167.60525021349173,167.60525021349173,167.60525021349173,167.60525021349173,167.60525021349173,167.60525021349173,167.60525021349173,167.60525021349173,167.60525021349173,167.60525021349173,167.60525021349173,173.07176633021265,173.07176633021265,173.07176633021265,173.07176633021265,173.07176633021265,173.07176633021265,173.07176633021265,173.07176633021265,173.07176633021265,173.07176633021265,178.53828244693358,178.53828244693358,178.53828244693358,178.53828244693358,178.53828244693358,178.53828244693358,178.53828244693358,178.53828244693358,178.53828244693358,178.53828244693358,184.00479856365448,184.00479856365448,184.00479856365448,184.00479856365448,184.00479856365448,184.00479856365448,184.00479856365448,184.00479856365448,189.4713146803754,189.4713146803754,189.4713146803754,189.4713146803754,189.4713146803754,189.4713146803754,189.4713146803754,189.4713146803754,194.9378307970963,194.9378307970963,194.9378307970963,194.9378307970963,200.40434691381722,200.40434691381722,200.40434691381722,200.40434691381722,205.87086303053815,205.87086303053815,205.87086303053815,205.87086303053815,211.33737914725907,211.33737914725907,211.33737914725907,211.33737914725907,211.33737914725907,216.80389526397997,222.2704113807009,222.2704113807009,222.2704113807009,227.7369274974218,227.7369274974218,227.7369274974218,233.2034436141427,238.66995973086364,238.66995973086364,238.66995973086364,244.13647584758456,244.13647584758456,260.53602419774734,266.0025403144682,266.0025403144682,271.46905643118913,271.46905643118913,282.4020886646309,282.4020886646309,287.8686047813519,309.73466924823555,315.2011853649565,670.524732951816,763.4555069360715,883.7188615039317,900.1184098540945,927.450990437699,1135.178602873094,1277.3080219078377],"yaxis":"y","type":"scatter"}],                        {"template":{"data":{"histogram2dcontour":[{"type":"histogram2dcontour","colorbar":{"outlinewidth":0,"ticks":""},"colorscale":[[0.0,"#0d0887"],[0.1111111111111111,"#46039f"],[0.2222222222222222,"#7201a8"],[0.3333333333333333,"#9c179e"],[0.4444444444444444,"#bd3786"],[0.5555555555555556,"#d8576b"],[0.6666666666666666,"#ed7953"],[0.7777777777777778,"#fb9f3a"],[0.8888888888888888,"#fdca26"],[1.0,"#f0f921"]]}],"choropleth":[{"type":"choropleth","colorbar":{"outlinewidth":0,"ticks":""}}],"histogram2d":[{"type":"histogram2d","colorbar":{"outlinewidth":0,"ticks":""},"colorscale":[[0.0,"#0d0887"],[0.1111111111111111,"#46039f"],[0.2222222222222222,"#7201a8"],[0.3333333333333333,"#9c179e"],[0.4444444444444444,"#bd3786"],[0.5555555555555556,"#d8576b"],[0.6666666666666666,"#ed7953"],[0.7777777777777778,"#fb9f3a"],[0.8888888888888888,"#fdca26"],[1.0,"#f0f921"]]}],"heatmap":[{"type":"heatmap","colorbar":{"outlinewidth":0,"ticks":""},"colorscale":[[0.0,"#0d0887"],[0.1111111111111111,"#46039f"],[0.2222222222222222,"#7201a8"],[0.3333333333333333,"#9c179e"],[0.4444444444444444,"#bd3786"],[0.5555555555555556,"#d8576b"],[0.6666666666666666,"#ed7953"],[0.7777777777777778,"#fb9f3a"],[0.8888888888888888,"#fdca26"],[1.0,"#f0f921"]]}],"heatmapgl":[{"type":"heatmapgl","colorbar":{"outlinewidth":0,"ticks":""},"colorscale":[[0.0,"#0d0887"],[0.1111111111111111,"#46039f"],[0.2222222222222222,"#7201a8"],[0.3333333333333333,"#9c179e"],[0.4444444444444444,"#bd3786"],[0.5555555555555556,"#d8576b"],[0.6666666666666666,"#ed7953"],[0.7777777777777778,"#fb9f3a"],[0.8888888888888888,"#fdca26"],[1.0,"#f0f921"]]}],"contourcarpet":[{"type":"contourcarpet","colorbar":{"outlinewidth":0,"ticks":""}}],"contour":[{"type":"contour","colorbar":{"outlinewidth":0,"ticks":""},"colorscale":[[0.0,"#0d0887"],[0.1111111111111111,"#46039f"],[0.2222222222222222,"#7201a8"],[0.3333333333333333,"#9c179e"],[0.4444444444444444,"#bd3786"],[0.5555555555555556,"#d8576b"],[0.6666666666666666,"#ed7953"],[0.7777777777777778,"#fb9f3a"],[0.8888888888888888,"#fdca26"],[1.0,"#f0f921"]]}],"surface":[{"type":"surface","colorbar":{"outlinewidth":0,"ticks":""},"colorscale":[[0.0,"#0d0887"],[0.1111111111111111,"#46039f"],[0.2222222222222222,"#7201a8"],[0.3333333333333333,"#9c179e"],[0.4444444444444444,"#bd3786"],[0.5555555555555556,"#d8576b"],[0.6666666666666666,"#ed7953"],[0.7777777777777778,"#fb9f3a"],[0.8888888888888888,"#fdca26"],[1.0,"#f0f921"]]}],"mesh3d":[{"type":"mesh3d","colorbar":{"outlinewidth":0,"ticks":""}}],"scatter":[{"fillpattern":{"fillmode":"overlay","size":10,"solidity":0.2},"type":"scatter"}],"parcoords":[{"type":"parcoords","line":{"colorbar":{"outlinewidth":0,"ticks":""}}}],"scatterpolargl":[{"type":"scatterpolargl","marker":{"colorbar":{"outlinewidth":0,"ticks":""}}}],"bar":[{"error_x":{"color":"#2a3f5f"},"error_y":{"color":"#2a3f5f"},"marker":{"line":{"color":"#E5ECF6","width":0.5},"pattern":{"fillmode":"overlay","size":10,"solidity":0.2}},"type":"bar"}],"scattergeo":[{"type":"scattergeo","marker":{"colorbar":{"outlinewidth":0,"ticks":""}}}],"scatterpolar":[{"type":"scatterpolar","marker":{"colorbar":{"outlinewidth":0,"ticks":""}}}],"histogram":[{"marker":{"pattern":{"fillmode":"overlay","size":10,"solidity":0.2}},"type":"histogram"}],"scattergl":[{"type":"scattergl","marker":{"colorbar":{"outlinewidth":0,"ticks":""}}}],"scatter3d":[{"type":"scatter3d","line":{"colorbar":{"outlinewidth":0,"ticks":""}},"marker":{"colorbar":{"outlinewidth":0,"ticks":""}}}],"scattermapbox":[{"type":"scattermapbox","marker":{"colorbar":{"outlinewidth":0,"ticks":""}}}],"scatterternary":[{"type":"scatterternary","marker":{"colorbar":{"outlinewidth":0,"ticks":""}}}],"scattercarpet":[{"type":"scattercarpet","marker":{"colorbar":{"outlinewidth":0,"ticks":""}}}],"carpet":[{"aaxis":{"endlinecolor":"#2a3f5f","gridcolor":"white","linecolor":"white","minorgridcolor":"white","startlinecolor":"#2a3f5f"},"baxis":{"endlinecolor":"#2a3f5f","gridcolor":"white","linecolor":"white","minorgridcolor":"white","startlinecolor":"#2a3f5f"},"type":"carpet"}],"table":[{"cells":{"fill":{"color":"#EBF0F8"},"line":{"color":"white"}},"header":{"fill":{"color":"#C8D4E3"},"line":{"color":"white"}},"type":"table"}],"barpolar":[{"marker":{"line":{"color":"#E5ECF6","width":0.5},"pattern":{"fillmode":"overlay","size":10,"solidity":0.2}},"type":"barpolar"}],"pie":[{"automargin":true,"type":"pie"}]},"layout":{"autotypenumbers":"strict","colorway":["#636efa","#EF553B","#00cc96","#ab63fa","#FFA15A","#19d3f3","#FF6692","#B6E880","#FF97FF","#FECB52"],"font":{"color":"#2a3f5f"},"hovermode":"closest","hoverlabel":{"align":"left"},"paper_bgcolor":"white","plot_bgcolor":"#E5ECF6","polar":{"bgcolor":"#E5ECF6","angularaxis":{"gridcolor":"white","linecolor":"white","ticks":""},"radialaxis":{"gridcolor":"white","linecolor":"white","ticks":""}},"ternary":{"bgcolor":"#E5ECF6","aaxis":{"gridcolor":"white","linecolor":"white","ticks":""},"baxis":{"gridcolor":"white","linecolor":"white","ticks":""},"caxis":{"gridcolor":"white","linecolor":"white","ticks":""}},"coloraxis":{"colorbar":{"outlinewidth":0,"ticks":""}},"colorscale":{"sequential":[[0.0,"#0d0887"],[0.1111111111111111,"#46039f"],[0.2222222222222222,"#7201a8"],[0.3333333333333333,"#9c179e"],[0.4444444444444444,"#bd3786"],[0.5555555555555556,"#d8576b"],[0.6666666666666666,"#ed7953"],[0.7777777777777778,"#fb9f3a"],[0.8888888888888888,"#fdca26"],[1.0,"#f0f921"]],"sequentialminus":[[0.0,"#0d0887"],[0.1111111111111111,"#46039f"],[0.2222222222222222,"#7201a8"],[0.3333333333333333,"#9c179e"],[0.4444444444444444,"#bd3786"],[0.5555555555555556,"#d8576b"],[0.6666666666666666,"#ed7953"],[0.7777777777777778,"#fb9f3a"],[0.8888888888888888,"#fdca26"],[1.0,"#f0f921"]],"diverging":[[0,"#8e0152"],[0.1,"#c51b7d"],[0.2,"#de77ae"],[0.3,"#f1b6da"],[0.4,"#fde0ef"],[0.5,"#f7f7f7"],[0.6,"#e6f5d0"],[0.7,"#b8e186"],[0.8,"#7fbc41"],[0.9,"#4d9221"],[1,"#276419"]]},"xaxis":{"gridcolor":"white","linecolor":"white","ticks":"","title":{"standoff":15},"zerolinecolor":"white","automargin":true,"zerolinewidth":2},"yaxis":{"gridcolor":"white","linecolor":"white","ticks":"","title":{"standoff":15},"zerolinecolor":"white","automargin":true,"zerolinewidth":2},"scene":{"xaxis":{"backgroundcolor":"#E5ECF6","gridcolor":"white","linecolor":"white","showbackground":true,"ticks":"","zerolinecolor":"white","gridwidth":2},"yaxis":{"backgroundcolor":"#E5ECF6","gridcolor":"white","linecolor":"white","showbackground":true,"ticks":"","zerolinecolor":"white","gridwidth":2},"zaxis":{"backgroundcolor":"#E5ECF6","gridcolor":"white","linecolor":"white","showbackground":true,"ticks":"","zerolinecolor":"white","gridwidth":2}},"shapedefaults":{"line":{"color":"#2a3f5f"}},"annotationdefaults":{"arrowcolor":"#2a3f5f","arrowhead":0,"arrowwidth":1},"geo":{"bgcolor":"white","landcolor":"#E5ECF6","subunitcolor":"white","showland":true,"showlakes":true,"lakecolor":"white"},"title":{"x":0.05},"mapbox":{"style":"light"}}},"xaxis":{"anchor":"y","domain":[0.0,1.0],"title":{"text":"commentsCount"}},"yaxis":{"anchor":"x","domain":[0.0,1.0],"title":{"text":"likesCount"}},"legend":{"tracegroupgap":0,"itemsizing":"constant"},"title":{"text":"Relationship Between Likes and Comments"}},                        {"responsive": true}                    ).then(function(){

var gd = document.getElementById('67ce5b25-cc51-4143-b2ba-3a932df39ed8');
var x = new MutationObserver(function (mutations, observer) {{
        var display = window.getComputedStyle(gd).display;
        if (!display || display === 'none') {{
            console.log([gd, 'removed!']);
            Plotly.purge(gd);
            observer.disconnect();
        }}
}});

// Listen for the removal of the full notebook cells
var notebookContainer = gd.closest('#notebook-container');
if (notebookContainer) {{
    x.observe(notebookContainer, {childList: true});
}}

// Listen for the clearing of the current output cell
var outputEl = gd.closest('.output');
if (outputEl) {{
    x.observe(outputEl, {childList: true});
}}

                        })                };                });            </script>        </div>



```python
figure = px.scatter(data_frame = df, x="videoViewCount",
                    y="likesCount", size="likesCount", trendline="ols", 
                    title = "Relationship Between Likes and videoViewCount")
figure.show()
```


<div>                            <div id="dc851d13-9cb6-4576-bcdd-8f4d2564dcb8" class="plotly-graph-div" style="height:525px; width:100%;"></div>            <script type="text/javascript">                require(["plotly"], function(Plotly) {                    window.PLOTLYENV=window.PLOTLYENV || {};                                    if (document.getElementById("dc851d13-9cb6-4576-bcdd-8f4d2564dcb8")) {                    Plotly.newPlot(                        "dc851d13-9cb6-4576-bcdd-8f4d2564dcb8",                        [{"hovertemplate":"videoViewCount=%{x}<br>likesCount=%{marker.size}<extra></extra>","legendgroup":"","marker":{"color":"#636efa","size":[507,658,493,413,438,628,547,543,655,381,468,456,218,428,443,440,483,163,312,336,431,341,378,192,128,199,413,657,19,46,60,41,29,33,15,78,350,39,162,68,29,83,22,50,484,22,165,80,152,113,1044,350,22,28,184,24,100,18,19,23,73,24,21,229,122,47,139,36,26,512,36,86,899,207,23,148,44,53,17,325,54,37,134,52,116,45,50,552,399,372,31,312,814,34,318,46,450,42,63,23,37,146,957,650,50,470,67,112,551,147,94,11,236,38,33,34,28,174,133,206,21,28,347,63,21,240,48,425,50,274,38,64,45,26,535,72,233,484,83,205,15,1034,38,316,32,171,93,82,139,108,37,56,930,39,967,249,160,63,4,152,93,23,503,48,14,147,80,10,440,53,55,164,485,28,16,221,714,152,33,147,114,52,149,42,10,96,172,134,281,21,6],"sizemode":"area","sizeref":2.61,"symbol":"circle"},"mode":"markers","name":"","orientation":"v","showlegend":false,"x":[null,11053.0,null,null,null,null,7152.0,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null],"xaxis":"x","y":[507,658,493,413,438,628,547,543,655,381,468,456,218,428,443,440,483,163,312,336,431,341,378,192,128,199,413,657,19,46,60,41,29,33,15,78,350,39,162,68,29,83,22,50,484,22,165,80,152,113,1044,350,22,28,184,24,100,18,19,23,73,24,21,229,122,47,139,36,26,512,36,86,899,207,23,148,44,53,17,325,54,37,134,52,116,45,50,552,399,372,31,312,814,34,318,46,450,42,63,23,37,146,957,650,50,470,67,112,551,147,94,11,236,38,33,34,28,174,133,206,21,28,347,63,21,240,48,425,50,274,38,64,45,26,535,72,233,484,83,205,15,1034,38,316,32,171,93,82,139,108,37,56,930,39,967,249,160,63,4,152,93,23,503,48,14,147,80,10,440,53,55,164,485,28,16,221,714,152,33,147,114,52,149,42,10,96,172,134,281,21,6],"yaxis":"y","type":"scatter"},{"hovertemplate":"<b>OLS trendline</b><br>likesCount = 0.0284542 * videoViewCount + 343.495<br>R<sup>2</sup>=1.000000<br><br>videoViewCount=%{x}<br>likesCount=%{y} <b>(trend)</b><extra></extra>","legendgroup":"","marker":{"color":"#636efa","symbol":"circle"},"mode":"lines","name":"","showlegend":false,"x":[7152.0,11053.0],"xaxis":"x","y":[546.9999999999997,657.9999999999998],"yaxis":"y","type":"scatter"}],                        {"template":{"data":{"histogram2dcontour":[{"type":"histogram2dcontour","colorbar":{"outlinewidth":0,"ticks":""},"colorscale":[[0.0,"#0d0887"],[0.1111111111111111,"#46039f"],[0.2222222222222222,"#7201a8"],[0.3333333333333333,"#9c179e"],[0.4444444444444444,"#bd3786"],[0.5555555555555556,"#d8576b"],[0.6666666666666666,"#ed7953"],[0.7777777777777778,"#fb9f3a"],[0.8888888888888888,"#fdca26"],[1.0,"#f0f921"]]}],"choropleth":[{"type":"choropleth","colorbar":{"outlinewidth":0,"ticks":""}}],"histogram2d":[{"type":"histogram2d","colorbar":{"outlinewidth":0,"ticks":""},"colorscale":[[0.0,"#0d0887"],[0.1111111111111111,"#46039f"],[0.2222222222222222,"#7201a8"],[0.3333333333333333,"#9c179e"],[0.4444444444444444,"#bd3786"],[0.5555555555555556,"#d8576b"],[0.6666666666666666,"#ed7953"],[0.7777777777777778,"#fb9f3a"],[0.8888888888888888,"#fdca26"],[1.0,"#f0f921"]]}],"heatmap":[{"type":"heatmap","colorbar":{"outlinewidth":0,"ticks":""},"colorscale":[[0.0,"#0d0887"],[0.1111111111111111,"#46039f"],[0.2222222222222222,"#7201a8"],[0.3333333333333333,"#9c179e"],[0.4444444444444444,"#bd3786"],[0.5555555555555556,"#d8576b"],[0.6666666666666666,"#ed7953"],[0.7777777777777778,"#fb9f3a"],[0.8888888888888888,"#fdca26"],[1.0,"#f0f921"]]}],"heatmapgl":[{"type":"heatmapgl","colorbar":{"outlinewidth":0,"ticks":""},"colorscale":[[0.0,"#0d0887"],[0.1111111111111111,"#46039f"],[0.2222222222222222,"#7201a8"],[0.3333333333333333,"#9c179e"],[0.4444444444444444,"#bd3786"],[0.5555555555555556,"#d8576b"],[0.6666666666666666,"#ed7953"],[0.7777777777777778,"#fb9f3a"],[0.8888888888888888,"#fdca26"],[1.0,"#f0f921"]]}],"contourcarpet":[{"type":"contourcarpet","colorbar":{"outlinewidth":0,"ticks":""}}],"contour":[{"type":"contour","colorbar":{"outlinewidth":0,"ticks":""},"colorscale":[[0.0,"#0d0887"],[0.1111111111111111,"#46039f"],[0.2222222222222222,"#7201a8"],[0.3333333333333333,"#9c179e"],[0.4444444444444444,"#bd3786"],[0.5555555555555556,"#d8576b"],[0.6666666666666666,"#ed7953"],[0.7777777777777778,"#fb9f3a"],[0.8888888888888888,"#fdca26"],[1.0,"#f0f921"]]}],"surface":[{"type":"surface","colorbar":{"outlinewidth":0,"ticks":""},"colorscale":[[0.0,"#0d0887"],[0.1111111111111111,"#46039f"],[0.2222222222222222,"#7201a8"],[0.3333333333333333,"#9c179e"],[0.4444444444444444,"#bd3786"],[0.5555555555555556,"#d8576b"],[0.6666666666666666,"#ed7953"],[0.7777777777777778,"#fb9f3a"],[0.8888888888888888,"#fdca26"],[1.0,"#f0f921"]]}],"mesh3d":[{"type":"mesh3d","colorbar":{"outlinewidth":0,"ticks":""}}],"scatter":[{"fillpattern":{"fillmode":"overlay","size":10,"solidity":0.2},"type":"scatter"}],"parcoords":[{"type":"parcoords","line":{"colorbar":{"outlinewidth":0,"ticks":""}}}],"scatterpolargl":[{"type":"scatterpolargl","marker":{"colorbar":{"outlinewidth":0,"ticks":""}}}],"bar":[{"error_x":{"color":"#2a3f5f"},"error_y":{"color":"#2a3f5f"},"marker":{"line":{"color":"#E5ECF6","width":0.5},"pattern":{"fillmode":"overlay","size":10,"solidity":0.2}},"type":"bar"}],"scattergeo":[{"type":"scattergeo","marker":{"colorbar":{"outlinewidth":0,"ticks":""}}}],"scatterpolar":[{"type":"scatterpolar","marker":{"colorbar":{"outlinewidth":0,"ticks":""}}}],"histogram":[{"marker":{"pattern":{"fillmode":"overlay","size":10,"solidity":0.2}},"type":"histogram"}],"scattergl":[{"type":"scattergl","marker":{"colorbar":{"outlinewidth":0,"ticks":""}}}],"scatter3d":[{"type":"scatter3d","line":{"colorbar":{"outlinewidth":0,"ticks":""}},"marker":{"colorbar":{"outlinewidth":0,"ticks":""}}}],"scattermapbox":[{"type":"scattermapbox","marker":{"colorbar":{"outlinewidth":0,"ticks":""}}}],"scatterternary":[{"type":"scatterternary","marker":{"colorbar":{"outlinewidth":0,"ticks":""}}}],"scattercarpet":[{"type":"scattercarpet","marker":{"colorbar":{"outlinewidth":0,"ticks":""}}}],"carpet":[{"aaxis":{"endlinecolor":"#2a3f5f","gridcolor":"white","linecolor":"white","minorgridcolor":"white","startlinecolor":"#2a3f5f"},"baxis":{"endlinecolor":"#2a3f5f","gridcolor":"white","linecolor":"white","minorgridcolor":"white","startlinecolor":"#2a3f5f"},"type":"carpet"}],"table":[{"cells":{"fill":{"color":"#EBF0F8"},"line":{"color":"white"}},"header":{"fill":{"color":"#C8D4E3"},"line":{"color":"white"}},"type":"table"}],"barpolar":[{"marker":{"line":{"color":"#E5ECF6","width":0.5},"pattern":{"fillmode":"overlay","size":10,"solidity":0.2}},"type":"barpolar"}],"pie":[{"automargin":true,"type":"pie"}]},"layout":{"autotypenumbers":"strict","colorway":["#636efa","#EF553B","#00cc96","#ab63fa","#FFA15A","#19d3f3","#FF6692","#B6E880","#FF97FF","#FECB52"],"font":{"color":"#2a3f5f"},"hovermode":"closest","hoverlabel":{"align":"left"},"paper_bgcolor":"white","plot_bgcolor":"#E5ECF6","polar":{"bgcolor":"#E5ECF6","angularaxis":{"gridcolor":"white","linecolor":"white","ticks":""},"radialaxis":{"gridcolor":"white","linecolor":"white","ticks":""}},"ternary":{"bgcolor":"#E5ECF6","aaxis":{"gridcolor":"white","linecolor":"white","ticks":""},"baxis":{"gridcolor":"white","linecolor":"white","ticks":""},"caxis":{"gridcolor":"white","linecolor":"white","ticks":""}},"coloraxis":{"colorbar":{"outlinewidth":0,"ticks":""}},"colorscale":{"sequential":[[0.0,"#0d0887"],[0.1111111111111111,"#46039f"],[0.2222222222222222,"#7201a8"],[0.3333333333333333,"#9c179e"],[0.4444444444444444,"#bd3786"],[0.5555555555555556,"#d8576b"],[0.6666666666666666,"#ed7953"],[0.7777777777777778,"#fb9f3a"],[0.8888888888888888,"#fdca26"],[1.0,"#f0f921"]],"sequentialminus":[[0.0,"#0d0887"],[0.1111111111111111,"#46039f"],[0.2222222222222222,"#7201a8"],[0.3333333333333333,"#9c179e"],[0.4444444444444444,"#bd3786"],[0.5555555555555556,"#d8576b"],[0.6666666666666666,"#ed7953"],[0.7777777777777778,"#fb9f3a"],[0.8888888888888888,"#fdca26"],[1.0,"#f0f921"]],"diverging":[[0,"#8e0152"],[0.1,"#c51b7d"],[0.2,"#de77ae"],[0.3,"#f1b6da"],[0.4,"#fde0ef"],[0.5,"#f7f7f7"],[0.6,"#e6f5d0"],[0.7,"#b8e186"],[0.8,"#7fbc41"],[0.9,"#4d9221"],[1,"#276419"]]},"xaxis":{"gridcolor":"white","linecolor":"white","ticks":"","title":{"standoff":15},"zerolinecolor":"white","automargin":true,"zerolinewidth":2},"yaxis":{"gridcolor":"white","linecolor":"white","ticks":"","title":{"standoff":15},"zerolinecolor":"white","automargin":true,"zerolinewidth":2},"scene":{"xaxis":{"backgroundcolor":"#E5ECF6","gridcolor":"white","linecolor":"white","showbackground":true,"ticks":"","zerolinecolor":"white","gridwidth":2},"yaxis":{"backgroundcolor":"#E5ECF6","gridcolor":"white","linecolor":"white","showbackground":true,"ticks":"","zerolinecolor":"white","gridwidth":2},"zaxis":{"backgroundcolor":"#E5ECF6","gridcolor":"white","linecolor":"white","showbackground":true,"ticks":"","zerolinecolor":"white","gridwidth":2}},"shapedefaults":{"line":{"color":"#2a3f5f"}},"annotationdefaults":{"arrowcolor":"#2a3f5f","arrowhead":0,"arrowwidth":1},"geo":{"bgcolor":"white","landcolor":"#E5ECF6","subunitcolor":"white","showland":true,"showlakes":true,"lakecolor":"white"},"title":{"x":0.05},"mapbox":{"style":"light"}}},"xaxis":{"anchor":"y","domain":[0.0,1.0],"title":{"text":"videoViewCount"}},"yaxis":{"anchor":"x","domain":[0.0,1.0],"title":{"text":"likesCount"}},"legend":{"tracegroupgap":0,"itemsizing":"constant"},"title":{"text":"Relationship Between Likes and videoViewCount"}},                        {"responsive": true}                    ).then(function(){

var gd = document.getElementById('dc851d13-9cb6-4576-bcdd-8f4d2564dcb8');
var x = new MutationObserver(function (mutations, observer) {{
        var display = window.getComputedStyle(gd).display;
        if (!display || display === 'none') {{
            console.log([gd, 'removed!']);
            Plotly.purge(gd);
            observer.disconnect();
        }}
}});

// Listen for the removal of the full notebook cells
var notebookContainer = gd.closest('#notebook-container');
if (notebookContainer) {{
    x.observe(notebookContainer, {childList: true});
}}

// Listen for the clearing of the current output cell
var outputEl = gd.closest('.output');
if (outputEl) {{
    x.observe(outputEl, {childList: true});
}}

                        })                };                });            </script>        </div>



```python
figure = px.scatter(data_frame = df, x="videoViewCount",
                    y="commentsCount", size="commentsCount", trendline="ols", 
                    title = "Relationship Between commentsCount and videoViewCount")
figure.show()

```


<div>                            <div id="63798dd1-79a2-4207-9827-04e6034ffa88" class="plotly-graph-div" style="height:525px; width:100%;"></div>            <script type="text/javascript">                require(["plotly"], function(Plotly) {                    window.PLOTLYENV=window.PLOTLYENV || {};                                    if (document.getElementById("63798dd1-79a2-4207-9827-04e6034ffa88")) {                    Plotly.newPlot(                        "63798dd1-79a2-4207-9827-04e6034ffa88",                        [{"hovertemplate":"videoViewCount=%{x}<br>commentsCount=%{marker.size}<extra></extra>","legendgroup":"","marker":{"color":"#636efa","size":[16,13,9,1,25,8,3,6,24,0,1,7,2,14,4,5,2,0,1,1,5,7,6,2,0,6,1,6,0,5,1,13,1,3,0,4,8,0,0,3,1,4,1,5,7,2,2,10,1,2,112,6,2,0,2,0,3,0,2,2,0,0,1,3,0,2,1,0,6,11,5,2,180,30,3,11,1,3,0,21,0,6,1,4,8,1,1,17,3,2,4,1,10,0,11,2,2,3,9,0,0,4,134,95,3,20,6,7,22,9,1,0,8,0,2,1,2,4,14,2,0,0,14,2,0,4,0,3,3,10,0,0,7,0,29,0,16,24,9,21,0,206,1,15,1,22,3,1,3,0,2,2,137,2,17,2,5,1,0,5,1,1,13,4,1,11,2,0,16,2,1,12,3,1,0,3,142,10,7,5,2,4,7,5,0,1,11,7,5,0,0],"sizemode":"area","sizeref":0.515,"symbol":"circle"},"mode":"markers","name":"","orientation":"v","showlegend":false,"x":[null,11053.0,null,null,null,null,7152.0,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null],"xaxis":"x","y":[16,13,9,1,25,8,3,6,24,0,1,7,2,14,4,5,2,0,1,1,5,7,6,2,0,6,1,6,0,5,1,13,1,3,0,4,8,0,0,3,1,4,1,5,7,2,2,10,1,2,112,6,2,0,2,0,3,0,2,2,0,0,1,3,0,2,1,0,6,11,5,2,180,30,3,11,1,3,0,21,0,6,1,4,8,1,1,17,3,2,4,1,10,0,11,2,2,3,9,0,0,4,134,95,3,20,6,7,22,9,1,0,8,0,2,1,2,4,14,2,0,0,14,2,0,4,0,3,3,10,0,0,7,0,29,0,16,24,9,21,0,206,1,15,1,22,3,1,3,0,2,2,137,2,17,2,5,1,0,5,1,1,13,4,1,11,2,0,16,2,1,12,3,1,0,3,142,10,7,5,2,4,7,5,0,1,11,7,5,0,0],"yaxis":"y","type":"scatter"},{"hovertemplate":"<b>OLS trendline</b><br>commentsCount = 0.00256345 * videoViewCount + -15.3338<br>R<sup>2</sup>=1.000000<br><br>videoViewCount=%{x}<br>commentsCount=%{y} <b>(trend)</b><extra></extra>","legendgroup":"","marker":{"color":"#636efa","symbol":"circle"},"mode":"lines","name":"","showlegend":false,"x":[7152.0,11053.0],"xaxis":"x","y":[3.0000000000000107,13.000000000000007],"yaxis":"y","type":"scatter"}],                        {"template":{"data":{"histogram2dcontour":[{"type":"histogram2dcontour","colorbar":{"outlinewidth":0,"ticks":""},"colorscale":[[0.0,"#0d0887"],[0.1111111111111111,"#46039f"],[0.2222222222222222,"#7201a8"],[0.3333333333333333,"#9c179e"],[0.4444444444444444,"#bd3786"],[0.5555555555555556,"#d8576b"],[0.6666666666666666,"#ed7953"],[0.7777777777777778,"#fb9f3a"],[0.8888888888888888,"#fdca26"],[1.0,"#f0f921"]]}],"choropleth":[{"type":"choropleth","colorbar":{"outlinewidth":0,"ticks":""}}],"histogram2d":[{"type":"histogram2d","colorbar":{"outlinewidth":0,"ticks":""},"colorscale":[[0.0,"#0d0887"],[0.1111111111111111,"#46039f"],[0.2222222222222222,"#7201a8"],[0.3333333333333333,"#9c179e"],[0.4444444444444444,"#bd3786"],[0.5555555555555556,"#d8576b"],[0.6666666666666666,"#ed7953"],[0.7777777777777778,"#fb9f3a"],[0.8888888888888888,"#fdca26"],[1.0,"#f0f921"]]}],"heatmap":[{"type":"heatmap","colorbar":{"outlinewidth":0,"ticks":""},"colorscale":[[0.0,"#0d0887"],[0.1111111111111111,"#46039f"],[0.2222222222222222,"#7201a8"],[0.3333333333333333,"#9c179e"],[0.4444444444444444,"#bd3786"],[0.5555555555555556,"#d8576b"],[0.6666666666666666,"#ed7953"],[0.7777777777777778,"#fb9f3a"],[0.8888888888888888,"#fdca26"],[1.0,"#f0f921"]]}],"heatmapgl":[{"type":"heatmapgl","colorbar":{"outlinewidth":0,"ticks":""},"colorscale":[[0.0,"#0d0887"],[0.1111111111111111,"#46039f"],[0.2222222222222222,"#7201a8"],[0.3333333333333333,"#9c179e"],[0.4444444444444444,"#bd3786"],[0.5555555555555556,"#d8576b"],[0.6666666666666666,"#ed7953"],[0.7777777777777778,"#fb9f3a"],[0.8888888888888888,"#fdca26"],[1.0,"#f0f921"]]}],"contourcarpet":[{"type":"contourcarpet","colorbar":{"outlinewidth":0,"ticks":""}}],"contour":[{"type":"contour","colorbar":{"outlinewidth":0,"ticks":""},"colorscale":[[0.0,"#0d0887"],[0.1111111111111111,"#46039f"],[0.2222222222222222,"#7201a8"],[0.3333333333333333,"#9c179e"],[0.4444444444444444,"#bd3786"],[0.5555555555555556,"#d8576b"],[0.6666666666666666,"#ed7953"],[0.7777777777777778,"#fb9f3a"],[0.8888888888888888,"#fdca26"],[1.0,"#f0f921"]]}],"surface":[{"type":"surface","colorbar":{"outlinewidth":0,"ticks":""},"colorscale":[[0.0,"#0d0887"],[0.1111111111111111,"#46039f"],[0.2222222222222222,"#7201a8"],[0.3333333333333333,"#9c179e"],[0.4444444444444444,"#bd3786"],[0.5555555555555556,"#d8576b"],[0.6666666666666666,"#ed7953"],[0.7777777777777778,"#fb9f3a"],[0.8888888888888888,"#fdca26"],[1.0,"#f0f921"]]}],"mesh3d":[{"type":"mesh3d","colorbar":{"outlinewidth":0,"ticks":""}}],"scatter":[{"fillpattern":{"fillmode":"overlay","size":10,"solidity":0.2},"type":"scatter"}],"parcoords":[{"type":"parcoords","line":{"colorbar":{"outlinewidth":0,"ticks":""}}}],"scatterpolargl":[{"type":"scatterpolargl","marker":{"colorbar":{"outlinewidth":0,"ticks":""}}}],"bar":[{"error_x":{"color":"#2a3f5f"},"error_y":{"color":"#2a3f5f"},"marker":{"line":{"color":"#E5ECF6","width":0.5},"pattern":{"fillmode":"overlay","size":10,"solidity":0.2}},"type":"bar"}],"scattergeo":[{"type":"scattergeo","marker":{"colorbar":{"outlinewidth":0,"ticks":""}}}],"scatterpolar":[{"type":"scatterpolar","marker":{"colorbar":{"outlinewidth":0,"ticks":""}}}],"histogram":[{"marker":{"pattern":{"fillmode":"overlay","size":10,"solidity":0.2}},"type":"histogram"}],"scattergl":[{"type":"scattergl","marker":{"colorbar":{"outlinewidth":0,"ticks":""}}}],"scatter3d":[{"type":"scatter3d","line":{"colorbar":{"outlinewidth":0,"ticks":""}},"marker":{"colorbar":{"outlinewidth":0,"ticks":""}}}],"scattermapbox":[{"type":"scattermapbox","marker":{"colorbar":{"outlinewidth":0,"ticks":""}}}],"scatterternary":[{"type":"scatterternary","marker":{"colorbar":{"outlinewidth":0,"ticks":""}}}],"scattercarpet":[{"type":"scattercarpet","marker":{"colorbar":{"outlinewidth":0,"ticks":""}}}],"carpet":[{"aaxis":{"endlinecolor":"#2a3f5f","gridcolor":"white","linecolor":"white","minorgridcolor":"white","startlinecolor":"#2a3f5f"},"baxis":{"endlinecolor":"#2a3f5f","gridcolor":"white","linecolor":"white","minorgridcolor":"white","startlinecolor":"#2a3f5f"},"type":"carpet"}],"table":[{"cells":{"fill":{"color":"#EBF0F8"},"line":{"color":"white"}},"header":{"fill":{"color":"#C8D4E3"},"line":{"color":"white"}},"type":"table"}],"barpolar":[{"marker":{"line":{"color":"#E5ECF6","width":0.5},"pattern":{"fillmode":"overlay","size":10,"solidity":0.2}},"type":"barpolar"}],"pie":[{"automargin":true,"type":"pie"}]},"layout":{"autotypenumbers":"strict","colorway":["#636efa","#EF553B","#00cc96","#ab63fa","#FFA15A","#19d3f3","#FF6692","#B6E880","#FF97FF","#FECB52"],"font":{"color":"#2a3f5f"},"hovermode":"closest","hoverlabel":{"align":"left"},"paper_bgcolor":"white","plot_bgcolor":"#E5ECF6","polar":{"bgcolor":"#E5ECF6","angularaxis":{"gridcolor":"white","linecolor":"white","ticks":""},"radialaxis":{"gridcolor":"white","linecolor":"white","ticks":""}},"ternary":{"bgcolor":"#E5ECF6","aaxis":{"gridcolor":"white","linecolor":"white","ticks":""},"baxis":{"gridcolor":"white","linecolor":"white","ticks":""},"caxis":{"gridcolor":"white","linecolor":"white","ticks":""}},"coloraxis":{"colorbar":{"outlinewidth":0,"ticks":""}},"colorscale":{"sequential":[[0.0,"#0d0887"],[0.1111111111111111,"#46039f"],[0.2222222222222222,"#7201a8"],[0.3333333333333333,"#9c179e"],[0.4444444444444444,"#bd3786"],[0.5555555555555556,"#d8576b"],[0.6666666666666666,"#ed7953"],[0.7777777777777778,"#fb9f3a"],[0.8888888888888888,"#fdca26"],[1.0,"#f0f921"]],"sequentialminus":[[0.0,"#0d0887"],[0.1111111111111111,"#46039f"],[0.2222222222222222,"#7201a8"],[0.3333333333333333,"#9c179e"],[0.4444444444444444,"#bd3786"],[0.5555555555555556,"#d8576b"],[0.6666666666666666,"#ed7953"],[0.7777777777777778,"#fb9f3a"],[0.8888888888888888,"#fdca26"],[1.0,"#f0f921"]],"diverging":[[0,"#8e0152"],[0.1,"#c51b7d"],[0.2,"#de77ae"],[0.3,"#f1b6da"],[0.4,"#fde0ef"],[0.5,"#f7f7f7"],[0.6,"#e6f5d0"],[0.7,"#b8e186"],[0.8,"#7fbc41"],[0.9,"#4d9221"],[1,"#276419"]]},"xaxis":{"gridcolor":"white","linecolor":"white","ticks":"","title":{"standoff":15},"zerolinecolor":"white","automargin":true,"zerolinewidth":2},"yaxis":{"gridcolor":"white","linecolor":"white","ticks":"","title":{"standoff":15},"zerolinecolor":"white","automargin":true,"zerolinewidth":2},"scene":{"xaxis":{"backgroundcolor":"#E5ECF6","gridcolor":"white","linecolor":"white","showbackground":true,"ticks":"","zerolinecolor":"white","gridwidth":2},"yaxis":{"backgroundcolor":"#E5ECF6","gridcolor":"white","linecolor":"white","showbackground":true,"ticks":"","zerolinecolor":"white","gridwidth":2},"zaxis":{"backgroundcolor":"#E5ECF6","gridcolor":"white","linecolor":"white","showbackground":true,"ticks":"","zerolinecolor":"white","gridwidth":2}},"shapedefaults":{"line":{"color":"#2a3f5f"}},"annotationdefaults":{"arrowcolor":"#2a3f5f","arrowhead":0,"arrowwidth":1},"geo":{"bgcolor":"white","landcolor":"#E5ECF6","subunitcolor":"white","showland":true,"showlakes":true,"lakecolor":"white"},"title":{"x":0.05},"mapbox":{"style":"light"}}},"xaxis":{"anchor":"y","domain":[0.0,1.0],"title":{"text":"videoViewCount"}},"yaxis":{"anchor":"x","domain":[0.0,1.0],"title":{"text":"commentsCount"}},"legend":{"tracegroupgap":0,"itemsizing":"constant"},"title":{"text":"Relationship Between commentsCount and videoViewCount"}},                        {"responsive": true}                    ).then(function(){

var gd = document.getElementById('63798dd1-79a2-4207-9827-04e6034ffa88');
var x = new MutationObserver(function (mutations, observer) {{
        var display = window.getComputedStyle(gd).display;
        if (!display || display === 'none') {{
            console.log([gd, 'removed!']);
            Plotly.purge(gd);
            observer.disconnect();
        }}
}});

// Listen for the removal of the full notebook cells
var notebookContainer = gd.closest('#notebook-container');
if (notebookContainer) {{
    x.observe(notebookContainer, {childList: true});
}}

// Listen for the clearing of the current output cell
var outputEl = gd.closest('.output');
if (outputEl) {{
    x.observe(outputEl, {childList: true});
}}

                        })                };                });            </script>        </div>


# Using Random Forest Regressor Model, which give more efficient results, with Ensemble R^2 Score: 0.99


```python
import numpy as np
import matplotlib.pyplot as plt
from sklearn.linear_model import LinearRegression
from sklearn.svm import SVR
from sklearn.ensemble import RandomForestRegressor, VotingRegressor
from sklearn.datasets import make_regression
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error, mean_absolute_error, r2_score
```


```python
# Generate a regression dataset
X, y = make_regression(n_samples=1000, n_features=10, n_informative=5, noise=0.5, random_state=42)
# Split the dataset into training and testing sets
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
```


```python
# Create the individual regression models
lr = LinearRegression()
svr = SVR(kernel='linear', C=1.0, epsilon=0.1)
rf = RandomForestRegressor(n_estimators=100, max_depth=5, random_state=42)
```


```python
# Create the ensemble model
ensemble = VotingRegressor(estimators=[('lr', lr), ('svr', svr), ('rf', rf)])
# Fit the ensemble model on the training data
ensemble.fit(X_train, y_train)
# Make predictions on the test set
y_pred = ensemble.predict(X_test)
```

# Now let’s predict the reach of an Instagram post by giving inputs to the machine learning model:


```python
# Calculate evaluation metrics
mse = mean_squared_error(y_test, y_pred)
mae = mean_absolute_error(y_test, y_pred)
r2 = r2_score(y_test, y_pred)
# Print the evaluation metrics for the ensemble model
print('Ensemble MSE:', mse)
print('Ensemble MAE:', mae)
print('Ensemble R^2 Score:', r2)
```

    Ensemble MSE: 39.47232633135599
    Ensemble MAE: 4.87555210643127
    Ensemble R^2 Score: 0.9903911840763783
    


```python
# Plotting the predictions vs. actual values
plt.scatter(y_test, y_pred, alpha=0.5)
plt.xlabel('True Values')
plt.ylabel('Predicted Values')
plt.title('Ensemble Model: Predicted vs. True Values')
plt.show()
```


    
![png](output_25_0.png)
    



```python

```
